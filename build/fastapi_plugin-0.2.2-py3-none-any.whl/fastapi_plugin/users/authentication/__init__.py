from fastapi_plugin.users.authentication.authenticator import Authenticator
from fastapi_plugin.users.authentication.backend import AuthenticationBackend
from fastapi_plugin.users.authentication.strategy import JWTStrategy, Strategy
from fastapi_plugin.users.authentication.transport import (
    BearerTransport,
    CookieTransport,
    Transport,
)

__all__ = [
    "Authenticator",
    "AuthenticationBackend",
    "BearerTransport",
    "CookieTransport",
    "JWTStrategy",
    "Strategy",
    "Transport",
]

try:
    from fastapi_plugin.users.authentication.strategy import RedisStrategy
    __all__.append("RedisStrategy")
except ImportError:  # pragma: no cover
    pass


