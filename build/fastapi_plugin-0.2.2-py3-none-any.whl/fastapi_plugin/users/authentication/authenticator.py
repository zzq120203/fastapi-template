from typing import Callable, Optional, Tuple, cast

from fastapi import Depends, HTTPException, status
from fastapi.security import SecurityScopes

from fastapi_plugin.common.typing import DependencyCallable
from fastapi_plugin.users.authentication.transport import Transport
from fastapi_plugin.users.authentication.strategy import Strategy
from fastapi_plugin.users.db import User, UserID
from fastapi_plugin.users.manager import UserManagerDependency


class Authenticator:

    def __init__(
            self,
            transport: Transport,
            get_strategy: DependencyCallable[Strategy[User, UserID]],
            get_user_manager: UserManagerDependency[User, UserID],
    ):
        self.transport = transport
        self.get_strategy = get_strategy
        self.get_user_manager = get_user_manager

    def current_user_token(
            self
    ):
        async def current_user_token_dependency(
                security_scopes: SecurityScopes,
                token=Depends(cast(Callable, self.transport.scheme)),
                strategy=Depends(self.get_strategy),
                user_manager=Depends(self.get_user_manager)
        ):
            user = await self._authenticate(
                security_scopes=security_scopes,
                token=token, strategy=strategy, user_manager=user_manager
            )
            return user

        return current_user_token_dependency

    def current_user(
            self,
    ):

        async def current_user_dependency(
                security_scopes: SecurityScopes,
                token=Depends(cast(Callable, self.transport.scheme)),
                strategy=Depends(self.get_strategy),
                user_manager=Depends(self.get_user_manager)
        ):
            user, _ = await self._authenticate(
                security_scopes=security_scopes,
                token=token, strategy=strategy, user_manager=user_manager
            )
            return user

        return current_user_dependency

    async def _authenticate(
            self,
            security_scopes: SecurityScopes,
            token: Optional[str],
            strategy,
            user_manager,
    ) -> Tuple[Optional[User], Optional[str]]:
        user: Optional[User] = None
        if token is not None:
            user = await strategy.read_token(token, user_manager)

        status_code = status.HTTP_401_UNAUTHORIZED
        if user:
            for scope in security_scopes.scopes:
                permissions = user.permissions.split() if user.permissions else []
                if scope not in permissions:
                    raise HTTPException(
                        status_code=status.HTTP_403_FORBIDDEN,
                        detail="Not enough permissions",
                    )
            if not user.is_active:
                status_code = status.HTTP_401_UNAUTHORIZED
                user = None
        if not user:
            raise HTTPException(status_code=status_code)
        return user, token
