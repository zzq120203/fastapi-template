from typing import Generic, Optional, Protocol

from fastapi_plugin.users.db import User, UserID
from fastapi_plugin.users.manager import BaseUserManager


class StrategyDestroyNotSupportedError(Exception):
    pass


class Strategy(Protocol, Generic[User, UserID]):  # noqa: F
    async def read_token(
        self, token: Optional[str], user_manager: BaseUserManager[User, UserID]
    ) -> Optional[User]:
        ...  # pragma: no cover

    async def write_token(self, user: User) -> str:
        ...  # pragma: no cover

    async def destroy_token(self, token: str, user: User) -> None:
        ...  # pragma: no cover
