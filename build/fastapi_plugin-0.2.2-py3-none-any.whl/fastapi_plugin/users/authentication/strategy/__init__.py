from fastapi_plugin.users.authentication.strategy.base import (
    Strategy,
    StrategyDestroyNotSupportedError,
)
from fastapi_plugin.users.authentication.strategy.jwt import JWTStrategy


__all__ = [
    "JWTStrategy",
    "Strategy",
    "StrategyDestroyNotSupportedError",
]

try:
    from fastapi_plugin.users.authentication.strategy import RedisStrategy
    __all__.append("RedisStrategy")
except ImportError:  # pragma: no cover
    pass
