from typing import Generic, Optional

from jose import JWTError

from fastapi_plugin.users import exceptions
from fastapi_plugin.users.authentication.strategy.base import (
    Strategy,
    StrategyDestroyNotSupportedError,
)
from fastapi_plugin.users.db import User, UserID
from fastapi_plugin.users.jwt import SecretType, decode_jwt, generate_jwt
from fastapi_plugin.users.manager import BaseUserManager


class JWTStrategy(Strategy[User, UserID], Generic[User, UserID]):
    def __init__(
        self,
        secret: SecretType,
        lifetime_minutes: Optional[int],
        algorithm: str = "HS256",
        public_key: Optional[SecretType] = None,
    ):
        self.secret = secret
        self.lifetime_minutes = lifetime_minutes
        self.algorithm = algorithm
        self.public_key = public_key

    @property
    def encode_key(self) -> SecretType:
        return self.secret

    @property
    def decode_key(self) -> SecretType:
        return self.public_key or self.secret

    async def read_token(
        self, token: Optional[str], user_manager: BaseUserManager[User, UserID]
    ) -> Optional[User]:
        if token is None:
            return None

        try:
            data = decode_jwt(
                token, self.decode_key, algorithms=self.algorithm
            )
            user_id = data.get("sub")
            if user_id is None:
                return None
        except JWTError:
            return None

        try:
            parsed_id = user_manager.parse_id(user_id)
            return await user_manager.get(parsed_id)
        except (exceptions.UserNotExists, exceptions.InvalidID):
            return None

    async def write_token(self, user: User) -> str:
        data = {"sub": str(user.id)}
        return generate_jwt(
            data, self.encode_key, self.lifetime_minutes, algorithm=self.algorithm
        )

    async def destroy_token(self, token: str, user: User) -> None:
        raise StrategyDestroyNotSupportedError(
            "A JWT can't be invalidated: it's valid until it expires."
        )
