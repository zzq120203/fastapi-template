import secrets
from typing import Generic, Optional

import redis.asyncio

from fastapi_plugin.users import exceptions
from fastapi_plugin.users.authentication.strategy.base import Strategy
from fastapi_plugin.users.db import UserID, User
from fastapi_plugin.users.manager import BaseUserManager


class RedisStrategy(Strategy[User, UserID], Generic[User, UserID]):
    def __init__(
        self,
        redis: redis.asyncio.Redis,
        lifetime_minutes: Optional[int] = None,
        *,
        key_prefix: str = "fastapi_users_token:",
    ):
        self.redis = redis
        self.lifetime_seconds = lifetime_minutes * 60
        self.key_prefix = key_prefix

    async def read_token(
        self, token: Optional[str], user_manager: BaseUserManager[User, UserID]
    ) -> Optional[User]:
        if token is None:
            return None

        user_id = await self.redis.get(f"{self.key_prefix}{token}")
        if user_id is None:
            return None

        try:
            parsed_id = user_manager.parse_id(user_id)
            return await user_manager.get(parsed_id)
        except (exceptions.UserNotExists, exceptions.InvalidID):
            return None

    async def write_token(self, user: User) -> str:
        token = secrets.token_urlsafe()
        await self.redis.set(
            f"{self.key_prefix}{token}", str(user.id), ex=self.lifetime_seconds
        )
        return token

    async def destroy_token(self, token: str, user: User) -> None:
        await self.redis.delete(f"{self.key_prefix}{token}")
