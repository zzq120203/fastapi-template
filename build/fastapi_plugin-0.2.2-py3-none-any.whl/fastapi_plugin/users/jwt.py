# !/usr/bin/env Python3
# -*- coding: utf-8 -*-
# @Author   : zhangzhanqi
# @FILE     : jwt.py
# @Time     : 2023/8/8 13:33
from datetime import datetime, timedelta
from typing import Any, Dict, Optional, Union

from jose import jwt
from pydantic import SecretStr

SecretType = Union[str, SecretStr]
JWT_ALGORITHM = "HS256"


def _get_secret_value(secret: SecretType) -> str:
    if isinstance(secret, SecretStr):
        return secret.get_secret_value()
    return secret


def generate_jwt(
        data: dict,
        secret: SecretType,
        expires_delta_minutes: Union[Optional[timedelta], int] = None,
        algorithm: str = JWT_ALGORITHM,
) -> str:
    payload = data.copy()
    if expires_delta_minutes:
        if isinstance(expires_delta_minutes, int):
            expires_delta_minutes = timedelta(minutes=expires_delta_minutes)
        expire = datetime.utcnow() + expires_delta_minutes
    else:
        expire = datetime.utcnow() + timedelta(minutes=15)
    payload.update({"exp": expire})
    return jwt.encode(payload, _get_secret_value(secret), algorithm=algorithm)


def decode_jwt(
        encoded_jwt: str,
        secret: SecretType,
        algorithms: Union[str, list] = JWT_ALGORITHM,
) -> Dict[str, Any]:
    return jwt.decode(
        encoded_jwt,
        _get_secret_value(secret),
        algorithms=algorithms,
    )
