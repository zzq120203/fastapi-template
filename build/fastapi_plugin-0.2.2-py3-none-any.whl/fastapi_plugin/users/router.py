# !/usr/bin/env Python3
# -*- coding: utf-8 -*-
# @Author   : zhangzhanqi
# @FILE     : router.py
# @Time     : 2023/8/11 9:58
from typing import Type, Sequence, Annotated, Tuple

from fastapi import APIRouter, Form, Depends, Body, HTTPException, status
from fastapi.requests import Request
from fastapi.security import OAuth2PasswordRequestForm

from fastapi_plugin.common.responses import GenericData, DataResponse
from fastapi_plugin.db.manager import BaseObjectManager
from fastapi_plugin.db.router import BaseObjectRouter
from fastapi_plugin.users import exceptions
from fastapi_plugin.users.authentication import Authenticator, AuthenticationBackend, Strategy
from fastapi_plugin.users.common import ErrorCode
from fastapi_plugin.users.db import (
    UR, UC, UU, User, UserID,
    BaseUserUpdate, BaseUserCreate, BaseUserRead,
    Role, RoleID, RR, RU, RC,
    BaseRoleRead, BaseRoleCreate, BaseRoleUpdate
)
from fastapi_plugin.users.manager import UserManagerDependency, BaseUserManager
from fastapi_plugin.users.permission import Permission


class UserOAuth2PasswordRequestForm(OAuth2PasswordRequestForm):
    def __init__(self, *, username: Annotated[str, Form()], password: Annotated[str, Form()]):
        super().__init__(username=username, password=password)


class BaseRoleRouter(BaseObjectRouter[Role, RoleID]):

    def __init__(
            self,
            get_user_manager: UserManagerDependency[User, UserID],
            *,
            name: str = None,
            schema_or: Type[RR] = BaseRoleRead,
            schema_oc: Type[RC] = BaseRoleCreate,
            schema_ou: Type[RU] = BaseRoleUpdate,
    ):
        async def get_role_manager(
                user_manager: BaseUserManager = Depends(get_user_manager),
        ):
            yield BaseObjectManager(user_manager.role_db)

        super().__init__(get_role_manager, name=name or 'role', schema_or=schema_or, schema_oc=schema_oc,
                         schema_ou=schema_ou)


class BaseUserRouter(BaseObjectRouter[User, UserID]):

    def __init__(
            self,
            auth_backend: AuthenticationBackend,
            get_user_manager: UserManagerDependency[User, UserID],
            *,
            name: str = None,
            schema_or: Type[UR] = BaseUserRead,
            schema_oc: Type[UC] = BaseUserCreate,
            schema_ou: Type[UU] = BaseUserUpdate,
    ) -> None:
        super().__init__(get_user_manager, name=name or 'user', schema_or=schema_or, schema_oc=schema_oc,
                         schema_ou=schema_ou)

        self.authenticator = Authenticator(auth_backend.transport, auth_backend.get_strategy, get_user_manager)
        self.auth_backend = auth_backend
        self.get_user_manager = get_user_manager
        self.current_user = self.authenticator.current_user

    def get_auth_router(
            cls,
    ) -> APIRouter:
        router = APIRouter(prefix=f"/auth/{cls.auth_backend.name}")
        get_current_user_token = cls.authenticator.current_user_token(
        )

        @router.post(
            "/login",
            name=f"auth:{cls.auth_backend.name}.login",
        )
        async def login(
                request: Request,
                credentials: UserOAuth2PasswordRequestForm = Depends(),
                user_manager: BaseUserManager[User, UserID] = Depends(cls.get_user_manager),
                strategy: Strategy[User, UserID] = Depends(cls.auth_backend.get_strategy),
        ):
            user = await user_manager.authenticate(credentials)
            if user is None or not user.is_active:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail=ErrorCode.LOGIN_BAD_CREDENTIALS,
                )
            response = await cls.auth_backend.login(strategy, user)
            await user_manager.on_after_login(user, request, response)
            return response

        @router.post(
            "/logout", name=f"auth:{cls.auth_backend.name}.logout"
        )
        async def logout(
                user_token: Tuple[User, str] = Depends(get_current_user_token),
                strategy: Strategy[User, UserID] = Depends(cls.auth_backend.get_strategy),
        ):
            user, token = user_token
            return await cls.auth_backend.logout(strategy, user, token)

        return router

    def verify_router(
            cls,
            name=None,
            dependencies: Sequence[Depends] | None = None,
            include_in_schema=True
    ):
        router = APIRouter(prefix="/verify")

        @router.post(
            "/verify",
            response_model=cls.OR,
            name=name or "verify:verify",
            dependencies=dependencies,
            include_in_schema=include_in_schema
        )
        async def verify(
                request: Request,
                token: str = Body(..., embed=True),
                user_manager: BaseUserManager[User, UserID] = Depends(cls.get_user_manager),
        ):
            try:
                user = await user_manager.verify(token, request)
                return cls.OR.model_validate(user)
            except (exceptions.InvalidVerifyToken, exceptions.UserNotExists):
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail=ErrorCode.VERIFY_USER_BAD_TOKEN,
                )
            except exceptions.UserAlreadyVerified:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail=ErrorCode.VERIFY_USER_ALREADY_VERIFIED,
                )

        return router

    def reset_router(
            cls,
            name=None,
            dependencies: Sequence[Depends] | None = None,
            include_in_schema=True
    ):
        router = APIRouter(prefix="/reset")

        @router.post(
            "/password",
            name=name or "reset:reset_password",
            dependencies=dependencies,
            include_in_schema=include_in_schema
        )
        async def reset_password(
                request: Request,
                token: str = Body(...),
                password: str = Body(...),
                user_manager: BaseUserManager[User, UserID] = Depends(cls.get_user_manager),
        ):
            try:
                await user_manager.reset_password(token, password, request)
            except (
                    exceptions.InvalidResetPasswordToken,
                    exceptions.UserNotExists,
                    exceptions.UserInactive,
            ):
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail=ErrorCode.RESET_PASSWORD_BAD_TOKEN,
                )
            except exceptions.InvalidPasswordException as e:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail={
                        "code": ErrorCode.RESET_PASSWORD_INVALID_PASSWORD,
                        "reason": e.reason,
                    },
                )

        return router

    def create_object_router(
            cls,
            name=None,
            dependencies: Sequence[Depends] | None = None,
            include_in_schema=True
    ) -> APIRouter:
        router = APIRouter(prefix=f"/auth/register")

        @router.post(
            "",
            name=f"register {name or 'user'}",
            dependencies=dependencies,
            include_in_schema=include_in_schema
        )
        async def register(
                request: Request,
                user_create: cls.OC = Body(...),
                user_manager: BaseUserManager[User, UserID] = Depends(cls.get_user_manager),
        ):
            try:
                created_user = await user_manager.create(
                    user_create, request=request
                )
            except exceptions.UserAlreadyExists:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail=ErrorCode.REGISTER_USER_ALREADY_EXISTS,
                )
            except exceptions.InvalidPasswordException as e:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail={
                        "code": ErrorCode.REGISTER_INVALID_PASSWORD,
                        "reason": e.reason,
                    },
                )

            return cls.OR.model_validate(created_user)

        return router

    def get_permission_router(
            cls,
            dependencies: Sequence[Depends] | None = None,
            include_in_schema=True
    ) -> APIRouter:
        router = APIRouter(prefix=f"/auth/permission")

        @router.post(
            "",
            response_model=GenericData[str],
            name=f'get permission',
            dependencies=dependencies,
            include_in_schema=include_in_schema,
        )
        async def get_permission(
        ):
            return DataResponse(data=Permission.instances)

        return router

    def get_current_user_router(cls):
        router = APIRouter(prefix=f"/auth/me")
        get_current_active_user = cls.current_user()

        @router.get(
            "",
            response_model=GenericData[cls.OR],
            name="users:current_user",
        )
        async def me(
                user: User = Depends(get_current_active_user),
        ):
            current_user = cls.OR.model_validate(user)
            return DataResponse(data=current_user)
        return router
