from typing import Any

from fastapi_plugin.common.exceptions import *


class UserAlreadyExists(AlreadyExists):
    pass


class UserNotExists(NotExists):
    pass


class UserInactive(FastAPIPluginException):
    pass


class UserAlreadyVerified(FastAPIPluginException):
    pass


class InvalidVerifyToken(FastAPIPluginException):
    pass


class InvalidResetPasswordToken(FastAPIPluginException):
    pass


class InvalidPasswordException(FastAPIPluginException):
    def __init__(self, reason: Any) -> None:
        self.reason = reason
