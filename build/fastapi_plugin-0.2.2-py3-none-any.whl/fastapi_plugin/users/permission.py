# !/usr/bin/env Python3
# -*- coding: utf-8 -*-
# @Author   : zhangzhanqi
# @FILE     : permission.py
# @Time     : 2023/8/8 13:51
from typing import Optional


class Permission(str):
    instances = []

    def __init__(self, name: str, doc: Optional[str] = None):
        Permission.instances.append(self)
        self.name = name
        self.doc = doc

    def __del__(self):
        for _, items in enumerate(Permission.instances):
            if items == self:
                Permission.instances.remove(items)

    def __str__(self):
        return self.name
