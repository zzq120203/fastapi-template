# !/usr/bin/env Python3
# -*- coding: utf-8 -*-
# @Author   : zhangzhanqi
# @FILE     : role.py
# @Time     : 2023/8/8 13:51
from typing import TYPE_CHECKING, Type, Generic, TypeVar, Optional

from pydantic import Field
from sqlalchemy import String, Integer
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import Mapped, mapped_column

from fastapi_plugin.db import SQLAlchemyObjectDatabase
from fastapi_plugin.db.models import ObjectProtocol
from fastapi_plugin.db.schemas import BaseObjectRead, BaseObjectCreate, BaseObjectUpdate
from fastapi_plugin.db.sqlalchemy import SQLAlchemyBaseObjectTableInt


class BaseRoleTable(SQLAlchemyBaseObjectTableInt):
    __tablename__ = 'fastapi_plugin_role'
    if TYPE_CHECKING:  # pragma: no cover
        permissions: str
    else:
        id: Mapped[int] = mapped_column(
            Integer(), autoincrement=True, primary_key=True
        )
        permissions: Mapped[str] = mapped_column(
            String(length=1024), nullable=False
        )


RT = TypeVar("RT", bound=BaseRoleTable)


class BaseRoleRead(BaseObjectRead[int]):
    permissions: str


class BaseRoleCreate(BaseObjectCreate):
    permissions: str


class BaseRoleUpdate(BaseObjectUpdate):
    permissions: Optional[str] = Field(None)


class BaseRoleProtocol(ObjectProtocol):
    permissions: str


RR = TypeVar("RR", bound=BaseRoleRead)
RC = TypeVar("RC", bound=BaseRoleCreate)
RU = TypeVar("RU", bound=BaseRoleUpdate)

RoleID = int
Role = TypeVar("Role", bound=BaseRoleProtocol)


class BaseRoleDatabase(Generic[Role], SQLAlchemyObjectDatabase[Role, RoleID]):
    def __init__(
            self,
            session: AsyncSession,
            role_table: Type[BaseRoleTable],
    ):
        super().__init__(session=session, object_table=role_table)
