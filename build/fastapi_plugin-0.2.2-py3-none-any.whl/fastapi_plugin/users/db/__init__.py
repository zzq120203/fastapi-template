# !/usr/bin/env Python3
# -*- coding: utf-8 -*-
# @Author   : zhangzhanqi
# @FILE     : __init__.py.py
# @Time     : 2023/8/8 13:51
import uuid
from datetime import datetime
from typing import TYPE_CHECKING, Type, TypeVar, Optional, List, Union, Tuple, Dict, Any

from pydantic import Field
from sqlalchemy import String, Boolean, ForeignKey, select, func, UnaryExpression, desc, Select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import Mapped, mapped_column, Session

from fastapi_plugin.db import SQLAlchemyBaseObjectTableUUID, SQLAlchemyObjectDatabase
from fastapi_plugin.db.models import ID, ObjectProtocol
from fastapi_plugin.db.schemas import BaseObjectRead, BaseObjectCreate, BaseObjectUpdate
from fastapi_plugin.db.sqlalchemy import PseudoAsyncSession
from fastapi_plugin.users.db.role import (
    BaseRoleTable, Role, RT, RoleID, BaseRoleDatabase,
    RR, RC, RU, BaseRoleRead, BaseRoleCreate, BaseRoleUpdate
)


class BaseUserTable(SQLAlchemyBaseObjectTableUUID):
    """
        id: UUID
        name: str
        create_time: datetime
        update_time: datetime
        hashed_password: str
        role: int
    """
    __tablename__ = 'fastapi_plugin_user'
    role__tablename__ = BaseRoleTable.__tablename__
    if TYPE_CHECKING:  # pragma: no cover
        hashed_password: str
        role_id: int
        is_active: int
    else:
        hashed_password: Mapped[str] = mapped_column(
            String(length=1024), nullable=False
        )
        role_id: Mapped[int] = mapped_column(
            ForeignKey(f"{role__tablename__}.id")
        )
        is_active: Mapped[bool] = mapped_column(
            Boolean, nullable=False
        )


class BaseUserRead(BaseObjectRead[uuid.UUID]):
    role_id: int
    is_active: int


class BaseUserCreate(BaseObjectCreate):
    hashed_password: str = Field(..., alias='password')
    role_id: int = Field(0)
    is_active: Optional[bool] = Field(True)


class BaseUserUpdate(BaseObjectUpdate):
    hashed_password: Optional[str] = Field(None, alias='password')
    role_id: Optional[int] = Field(None)
    is_active: Optional[bool] = Field(None)


class BaseUserProtocol(ObjectProtocol):
    hashed_password: str
    role_id: Optional[int] = Field(None)
    permissions: Optional[str] = Field(None)
    is_active: Optional[bool] = Field(None)


UR = TypeVar("UR", bound=BaseUserRead)
UC = TypeVar("UC", bound=BaseUserCreate)
UU = TypeVar("UU", bound=BaseUserUpdate)

UserID = ID
User = TypeVar("User", bound=BaseUserProtocol)


class BaseUserDatabase(SQLAlchemyObjectDatabase[User, UserID]):
    session: Union[AsyncSession, PseudoAsyncSession]
    user_table: Type[BaseUserTable]
    role_table: Type[BaseRoleTable]

    def __init__(
            self,
            session: Union[AsyncSession, Session],
            user_table: Type[BaseUserTable],
            role_table: Type[BaseRoleTable] = BaseRoleTable,
    ):
        super().__init__(session=session, object_table=user_table)
        self.user_table = user_table
        self.role_table = role_table

        self.role = BaseRoleDatabase[Role](session, role_table)

    async def get(self, id: ID) -> Optional[User]:
        statement = select(self.user_table).where(self.user_table.id == id)
        return await self._get_obj(statement)

    async def get_by_name(self, name: str) -> Optional[User]:
        statement = select(self.user_table).where(
            func.lower(self.user_table.name) == func.lower(name)
        )
        return await self._get_obj(statement)

    async def get_all(
            self,
            query=None,
            order_by: List[Union[str, UnaryExpression]] = None,
            offset: Optional[int] = 1,
            limit: Optional[int] = None,
    ) -> Tuple[List[User], int]:
        statement = select(self.user_table)
        if query is not None:
            statement = statement.filter(query)
        total: int = await self._count(statement)
        if order_by:
            for ob in order_by:
                if isinstance(ob, str) and ob.startswith("-"):
                    statement = statement.order_by(desc(ob[1:]))
                else:
                    statement = statement.order_by(ob)
        if limit:
            statement = statement.offset(offset).limit(limit)
        objs = await self._get_objs(statement)
        return objs, total

    async def create(self, create_dict: Dict[str, Any]) -> User:
        if "create_time" not in create_dict:
            create_dict["create_time"] = datetime.now()
        if "update_time" not in create_dict:
            create_dict["update_time"] = datetime.now()
        obj = self.user_table(**create_dict)
        self.session.add(obj)
        await self.session.commit()
        return obj

    async def update(self, obj: User, update_dict: Dict[str, Any]) -> User:
        if "update_time" not in update_dict:
            update_dict["update_time"] = datetime.now()
        for key, value in update_dict.items():
            setattr(obj, key, value)
        self.session.add(obj)
        await self.session.commit()
        return obj

    async def delete(self, obj: User) -> None:
        await self.session.delete(obj)
        await self.session.commit()

    async def _get_obj(self, statement: Select) -> Optional[User]:
        results = await self.session.execute(statement)
        return results.unique().scalar_one_or_none()

    async def _get_objs(self, statement: Select) -> List[User]:
        results = await self.session.execute(statement)
        return results.unique().scalars().all()

    async def _count(self, statement: Select) -> int:
        statement = statement.with_only_columns(func.count()).select_from(self.user_table)
        count = await self.session.execute(statement)
        return count.scalar()
