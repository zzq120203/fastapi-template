# !/usr/bin/env Python3
# -*- coding: utf-8 -*-
# @Author   : zhangzhanqi
# @FILE     : exception_handlers.py
# @Time     : 2023/8/7 11:42
from fastapi.encoders import jsonable_encoder
from fastapi.exceptions import HTTPException, RequestValidationError
from fastapi.logger import logger
from fastapi.openapi import utils as fu
from fastapi.requests import Request

from fastapi_plugin.common.exceptions import FastAPIPluginException
from fastapi_plugin.common.responses import DataResponse

fu.validation_error_response_definition = {
    "title": "HTTPValidationError",
    "type": "object",
    "properties": {
        "code": {"title": "code", "type": "integer", "default": 422},
        "message": {"title": "Message", "type": "string", "default": ""},
    },
    "required": ["code", "message"],
}


async def http_exception_handler(
        request: Request,
        exc: HTTPException
) -> DataResponse:
    return DataResponse(message=exc.detail, code=exc.status_code)


async def request_validation_exception_handler(
        request: Request,
        exc: RequestValidationError
) -> DataResponse:
    """
    捕捉422报错并进行自定义处理
    :param request:
    :param exc:
    :return:
    """
    messages = [f'{msg["type"]}:{msg["loc"]}({msg.get("input", None)}):{msg["msg"]}' for msg in
                jsonable_encoder(exc.errors())]
    message = ", ".join(messages)
    logger.warning(f'{request.method} {request.scope["path"]} {message}')
    return DataResponse(message=message, code=422)


async def fastapi_plugin_exception_handler(
        request: Request,
        exc: FastAPIPluginException
) -> DataResponse:
    return DataResponse(message=str(exc), code=400)
