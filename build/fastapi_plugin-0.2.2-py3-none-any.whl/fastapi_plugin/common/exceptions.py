class FastAPIPluginException(Exception):
    pass


class InvalidID(FastAPIPluginException):
    pass


class AlreadyExists(FastAPIPluginException):
    pass


class NotExists(FastAPIPluginException):
    pass
