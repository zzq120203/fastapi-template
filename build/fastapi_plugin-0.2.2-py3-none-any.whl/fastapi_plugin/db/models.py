# !/usr/bin/env Python3
# -*- coding: utf-8 -*-
# @Author   : zhangzhanqi
# @FILE     : models.py
# @Time     : 2023/8/2 12:55
from datetime import datetime
from typing import Protocol, TypeVar

ID = TypeVar("ID")


class ObjectProtocol(Protocol[ID]):
    """Object protocol that ORM model should follow."""

    id: ID
    name: str
    create_time: datetime
    update_time: datetime

    def __init__(self, *args, **kwargs) -> None:
        ...  # pragma: no cover


Object = TypeVar("Object", bound=ObjectProtocol)

