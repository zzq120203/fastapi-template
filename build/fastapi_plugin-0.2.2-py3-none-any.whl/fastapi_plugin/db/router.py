# !/usr/bin/env Python3
# -*- coding: utf-8 -*-
# @Author   : zhangzhanqi
# @FILE     : router.py
# @Time     : 2023/8/2 14:40
from typing import Optional, List, Type, Generic, Tuple

from fastapi import (
    Depends, APIRouter,
    Body, Request, HTTPException,
    status, Query
)
from pydantic import BaseModel

from fastapi_plugin.common import exceptions
from fastapi_plugin.common.responses import DataResponse, GenericData
from fastapi_plugin.common.typing import LIMIT, OFFSET
from fastapi_plugin.db import schemas
from fastapi_plugin.db.manager import ObjectManagerDependency, BaseObjectManager
from fastapi_plugin.db.models import Object, ID


class BaseObjectRouter(Generic[Object, ID]):
    def __init__(
            self,
            get_object_manager: ObjectManagerDependency[Object, ID],
            *,
            name: Optional[str] = None,
            schema_or: Type[schemas.OR] = schemas.BaseObjectRead,
            schema_oc: Type[schemas.OC] = schemas.BaseObjectCreate,
            schema_ou: Type[schemas.OU] = schemas.BaseObjectUpdate,
    ) -> None:
        self.OR = schema_or
        self.OC = schema_oc
        self.OU = schema_ou
        self.name = name or (self.OR.__name__.lower())

        self.get_object_manager = get_object_manager

    def create_object_router(
            cls,
    ) -> APIRouter:
        router = APIRouter(prefix=f"/{cls.name}")

        @router.post(
            "",
            response_model=GenericData[cls.OR],
            name=f'create {cls.name}',
        )
        async def __create_object(
                request: Request,
                obj: cls.OC = Body(...),
                object_manager: BaseObjectManager[Object, ID] = Depends(cls.get_object_manager)
        ):
            obj = await object_manager.create(obj, request=request)
            return DataResponse(data=schemas.model_validate(cls.OR, obj))

        return router

    def get_object_router(
            cls,
    ) -> APIRouter:
        class ItemsData(BaseModel):
            items: List[cls.OR]
            total: int

        async def __get_obj_or_404(
                id: str,
                object_manager: BaseObjectManager[Object, ID] = Depends(cls.get_object_manager)
        ):
            try:
                parsed_id = object_manager.parse_id(id)
                return await object_manager.get(parsed_id)
            except (exceptions.NotExists, exceptions.InvalidID) as e:
                raise HTTPException(status_code=status.HTTP_404_NOT_FOUND) from e

        router = APIRouter(
            prefix=f"/{cls.name}",
        )

        @router.get(
            "",
            response_model=GenericData[ItemsData],
            name=f'get {cls.name} all',
        )
        async def __get_objects(
                request: Request,
                object_manager: BaseObjectManager[Object, ID] = Depends(cls.get_object_manager),
                query=Depends(cls.get_objects_query),
                order_by=Depends(cls.get_objects_order_by),
                page=Depends(cls.get_objects_limit_offset),
        ):
            limit, offset = page
            objs, total = await object_manager.get_all(query=query, order_by=order_by, offset=offset, limit=limit)
            return DataResponse(data={
                "items": [cls.OR.model_validate(obj) for obj in objs],
                "total": total
            })

        @router.get(
            "/{id}",
            response_model=GenericData[cls.OR],
            name=f'get {cls.name} by id'
        )
        async def __get_object(
                request: Request,
                obj=Depends(__get_obj_or_404),
        ):
            obj = cls.OR.model_validate(obj)
            return DataResponse(data=cls.OR.model_validate(obj))

        return router

    def update_object_router(
            cls,
    ) -> APIRouter:

        async def __get_obj_or_404(
                id: str,
                object_manager: BaseObjectManager[Object, ID] = Depends(cls.get_object_manager)
        ):
            try:
                parsed_id = object_manager.parse_id(id)
                return await object_manager.get(parsed_id)
            except (exceptions.NotExists, exceptions.InvalidID) as e:
                raise HTTPException(status_code=status.HTTP_404_NOT_FOUND) from e

        router = APIRouter(prefix=f"/{cls.name}",)

        @router.patch(
            "/{id}",
            response_model=GenericData[cls.OR],
            name=f'update {cls.name} by id',
        )
        async def __update_object(
                request: Request,
                obj_update: cls.OU = Body(...),
                obj=Depends(__get_obj_or_404),
                object_manager: BaseObjectManager[Object, ID] = Depends(cls.get_object_manager)
        ):
            obj = await object_manager.update(obj_update, obj, request=request)
            return DataResponse(data=cls.OR.model_validate(obj))

        return router

    def delete_object_router(
            cls,
    ) -> APIRouter:

        async def __get_obj_or_404(
                id: str,
                object_manager: BaseObjectManager[Object, ID] = Depends(cls.get_object_manager)
        ):
            try:
                parsed_id = object_manager.parse_id(id)
                return await object_manager.get(parsed_id)
            except (exceptions.NotExists, exceptions.InvalidID) as e:
                raise HTTPException(status_code=status.HTTP_404_NOT_FOUND) from e

        router = APIRouter(prefix=f"/{cls.name}",)

        @router.delete(
            "/{id}",
            response_model=GenericData[cls.OR],
            name=f'delete {cls.name} by id',
        )
        async def __delete_object(
                request: Request,
                obj=Depends(__get_obj_or_404),
                object_manager: BaseObjectManager[Object, ID] = Depends(cls.get_object_manager)
        ):
            await object_manager.delete(obj, request=request)
            return DataResponse(data=cls.OR.model_validate(obj))

        return router

    async def get_objects_query(self):
        """
        async def get_objects_query(
            self,
            name: Optional[str] = Query(None),
            phone: Optional[str] = Query(None),
            car_number: Optional[str] = Query(None),
        ):
            query = []

            if name:
                query.append(PersonTable.name == name)
            if phone:
                query.append(PersonTable.phone == phone)
            if car_number:
                query.append(PersonTable.car_number == car_number)
            return and_(*query) if query else None
        """
        pass

    async def get_objects_order_by(self, order_by: List[str] = Query(['-create_time'])):
        """
        async def get_objects_order_by(self, order_by: List[str] = Query(['-create_time'])):

            return order_by
        """
        return order_by

    async def get_objects_limit_offset(
            self,
            page: int = Query(1),
            page_size: Optional[int] = Query(None)
    ) -> Tuple[LIMIT, OFFSET]:
        """
        async def get_objects_limit_offset(
                self,
                limit: Optional[int] = Query(None),
                offset: int = Query(0)
        ) -> Tuple[LIMIT, OFFSET]:
            return limit, offset
        or:
        async def get_objects_limit_offset(
            self, page: int = Query(1),
            page_size: Optional[int] = Query(None)
        ) -> Tuple[LIMIT, OFFSET]:
            offset = (page - 1) * page_size if page and page_size else 0
            limit = page_size
            return limit, offset
        """
        offset = (page - 1) * page_size if page and page_size else 0
        limit = page_size
        return limit, offset
