# !/usr/bin/env Python3
# -*- coding: utf-8 -*-
# @Author   : zhangzhanqi
# @FILE     : __init__.py.py
# @Time     : 2023/8/2 11:52
import uuid
from datetime import datetime
from typing import Generic, TYPE_CHECKING, Type, Dict, Any, Optional, List, Tuple, Union

from fastapi.logger import logger
from sqlalchemy import String, func, select, DateTime, UnaryExpression, desc, Integer
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import Session, Mapped, mapped_column
from sqlalchemy.sql import Select

from fastapi_plugin.db.base import BaseObjectDatabase
from fastapi_plugin.db.models import ID, Object
from fastapi_plugin.db.sqlalchemy._session_func_to_async import PseudoAsyncSession
from fastapi_plugin.db.sqlalchemy.generics import GUID

UUID_ID = uuid.UUID


class SQLAlchemyBaseObjectTable(Generic[ID]):
    """Base SQLAlchemy object table definition."""

    __tablename__ = "object"

    if TYPE_CHECKING:  # pragma: no cover
        id: ID
        name: str
        # zhang
        create_time: datetime
        update_time: datetime
    else:
        name: Mapped[str] = mapped_column(
            String(length=256), unique=True, index=True, nullable=False
        )
        create_time: Mapped[datetime] = mapped_column(
            DateTime(), nullable=False
        )
        update_time: Mapped[datetime] = mapped_column(
            DateTime(), nullable=False
        )


class SQLAlchemyBaseObjectTableInt(SQLAlchemyBaseObjectTable[int]):
    if TYPE_CHECKING:  # pragma: no cover
        id: int
    else:
        id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)


class SQLAlchemyBaseObjectTableUUID(SQLAlchemyBaseObjectTable[UUID_ID]):
    if TYPE_CHECKING:  # pragma: no cover
        id: UUID_ID
    else:
        id: Mapped[UUID_ID] = mapped_column(GUID, primary_key=True, default=uuid.uuid4)


class SQLAlchemyObjectDatabase(Generic[Object, ID], BaseObjectDatabase[Object, ID]):
    """
    Database adapter for SQLAlchemy.

    :param session: SQLAlchemy session instance.
    :param object_table: SQLAlchemy object model.
    """

    session: Union[AsyncSession, PseudoAsyncSession]
    object_table: Type[SQLAlchemyBaseObjectTable]

    def __init__(
            self,
            session: Union[AsyncSession, Session],
            object_table: Type[SQLAlchemyBaseObjectTable],
    ):
        if isinstance(session, Session):
            logger.warning("""AsyncSession is recommended for performance reasons.
Refer:
    postgresql+psycopg, postgresql+psycopg_async, postgresql+asyncpg, postgresql+aiopg,
    mysql+aiomysql, mysql+asyncmy,
    sqlite+aiosqlite
    https://docs.sqlalchemy.org/en/20/dialects/index.html """)
            self.session = PseudoAsyncSession(session)
        else:
            self.session = session
        self.object_table = object_table

    async def get(self, id: ID) -> Optional[Object]:
        statement = select(self.object_table).where(self.object_table.id == id)
        return await self._get_obj(statement)

    async def get_by_name(self, name: str) -> Optional[Object]:
        statement = select(self.object_table).where(
            func.lower(self.object_table.name) == func.lower(name)
        )
        return await self._get_obj(statement)

    async def get_all(
            self,
            query=None,
            order_by: List[Union[str, UnaryExpression]] = None,
            offset: Optional[int] = 1,
            limit: Optional[int] = None,
    ) -> Tuple[List[Object], int]:
        statement = select(self.object_table)
        if query is not None:
            statement = statement.filter(query)
        total: int = await self._count(statement)
        if order_by:
            for ob in order_by:
                if isinstance(ob, str) and ob.startswith("-"):
                    statement = statement.order_by(desc(ob[1:]))
                else:
                    statement = statement.order_by(ob)
        if limit:
            statement = statement.offset(offset).limit(limit)
        objs = await self._get_objs(statement)
        return objs, total

    async def create(self, create_dict: Dict[str, Any]) -> Object:
        if "create_time" not in create_dict:
            create_dict["create_time"] = datetime.now()
        if "update_time" not in create_dict:
            create_dict["update_time"] = datetime.now()
        obj = self.object_table(**create_dict)
        self.session.add(obj)
        await self.session.commit()
        return obj

    async def update(self, obj: Object, update_dict: Dict[str, Any]) -> Object:
        if "update_time" not in update_dict:
            update_dict["update_time"] = datetime.now()
        for key, value in update_dict.items():
            setattr(obj, key, value)
        self.session.add(obj)
        await self.session.commit()
        return obj

    async def delete(self, obj: Object) -> None:
        await self.session.delete(obj)
        await self.session.commit()

    async def _get_obj(self, statement: Select) -> Optional[Object]:
        results = await self.session.execute(statement)
        return results.unique().scalar_one_or_none()

    async def _get_objs(self, statement: Select) -> List[Object]:
        results = await self.session.execute(statement)
        return results.unique().scalars().all()

    async def _count(self, statement: Select) -> int:
        statement = statement.with_only_columns(func.count()).select_from(self.object_table)
        count = await self.session.execute(statement)
        return count.scalar()
