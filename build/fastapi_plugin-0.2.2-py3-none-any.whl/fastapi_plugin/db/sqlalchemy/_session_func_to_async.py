# !/usr/bin/env Python3
# -*- coding: utf-8 -*-
# @Author   : zhangzhanqi
# @FILE     : session_func_to_async.py
# @Time     : 2023/8/17 10:43
from typing import Any

from sqlalchemy import util, Result, Executable
from sqlalchemy.orm import Session


class PseudoAsyncSession(object):

    def __init__(self, session: Session):
        self.session = session

    def add(self, instance: object, _warn: bool = True) -> None:
        self.session.add(instance=instance, _warn=_warn)

    async def commit(self) -> None:
        self.session.commit()

    async def delete(self, instance: object) -> None:
        self.session.delete(instance=instance)

    async def execute(
            self,
            statement: Executable,
            params=None,
            *,
            execution_options=util.EMPTY_DICT,
            bind_arguments=None,
            **kw: Any,
    ) -> Result[Any]:
        return self.session.execute(
            statement, params,
            execution_options=execution_options,
            bind_arguments=bind_arguments,
            **kw
        )
