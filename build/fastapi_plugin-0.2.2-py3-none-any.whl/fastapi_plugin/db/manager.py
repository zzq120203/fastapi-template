# !/usr/bin/env Python3
# -*- coding: utf-8 -*-
# @Author   : zhangzhanqi
# @FILE     : manager.py
# @Time     : 2023/8/2 13:49
import uuid
from typing import Any, Dict, Generic, Optional, List, Tuple

from fastapi import Request

from fastapi_plugin.common import exceptions
from fastapi_plugin.common.typing import DependencyCallable
from fastapi_plugin.db import schemas, BaseObjectDatabase
from fastapi_plugin.db.models import Object, ID


class BaseObjectManager(Generic[Object, ID]):
    object_db: BaseObjectDatabase[Object, ID]

    def __init__(
            self,
            object_db: BaseObjectDatabase[Object, ID],
    ):
        self.object_db = object_db

    def parse_id(self, value: Any) -> ID:
        raise NotImplementedError()  # pragma: no cover

    async def get(self, obg_id: ID) -> Object:
        obj = await self.object_db.get(obg_id)

        if obj is None:
            raise exceptions.NotExists(f"{obg_id} not exists.")

        return obj

    async def get_by_name(self, obj_name: str) -> Object:
        obj = await self.object_db.get_by_name(obj_name)

        if obj is None:
            raise exceptions.NotExists(f"{obj_name} not exists.")

        return obj

    async def get_all(
            self,
            query=None,
            order_by: List[str] = None,
            offset: Optional[int] = 1,
            limit: Optional[int] = None,
    ) -> Tuple[List[Object], int]:
        objs, total = await self.object_db.get_all(query=query, order_by=order_by, offset=offset, limit=limit)
        return objs, total

    async def create(
            self,
            object_create: schemas.OC,
            request: Optional[Request] = None,
    ) -> Object:

        existing_object = await self.object_db.get_by_name(object_create.name)
        if existing_object is not None:
            raise exceptions.AlreadyExists(f"{object_create.name} is already exists.")

        object_dict = object_create.create_update_dict()

        created_object = await self.object_db.create(object_dict)

        await self.on_after_create(created_object, request)

        return created_object

    async def update(
            self,
            object_update: schemas.OU,
            object: Object,
            request: Optional[Request] = None,
    ) -> Object:

        updated_object_data = object_update.create_update_dict()
        updated_object = await self._update(object, updated_object_data)
        await self.on_after_update(updated_object, updated_object_data, request)
        return updated_object

    async def delete(
            self,
            object: Object,
            request: Optional[Request] = None,
    ) -> None:
        await self.on_before_delete(object, request)
        await self.object_db.delete(object)
        await self.on_after_delete(object, request)

    async def on_after_create(
            self, obj: Object, request: Optional[Request] = None
    ) -> None:
        return  # pragma: no cover

    async def on_after_update(
            self,
            user: Object,
            update_dict: Dict[str, Any],
            request: Optional[Request] = None,
    ) -> None:
        return  # pragma: no cover

    async def on_before_delete(
            self, obj: Object, request: Optional[Request] = None
    ) -> None:
        return  # pragma: no cover

    async def on_after_delete(
            self, obj: Object, request: Optional[Request] = None
    ) -> None:
        return  # pragma: no cover

    async def _update(self, obj: Object, update_dict: Dict[str, Any]) -> Object:
        validated_update_dict = {}
        for field, value in update_dict.items():
            if field == "name" and value != obj.name:
                try:
                    await self.get_by_name(value)
                    raise exceptions.AlreadyExists(f"{obj.name} is already exists.")
                except exceptions.NotExists:
                    validated_update_dict["name"] = value
            else:
                validated_update_dict[field] = value
        return await self.object_db.update(obj, validated_update_dict)


class UUIDIDMixin:
    def parse_id(self, value: Any) -> uuid.UUID:
        if isinstance(value, uuid.UUID):
            return value
        try:
            return uuid.UUID(value)
        except ValueError as e:
            raise exceptions.InvalidID() from e


class IntegerIDMixin:
    def parse_id(self, value: Any) -> int:
        if isinstance(value, float):
            raise exceptions.InvalidID()
        try:
            return int(value)
        except ValueError as e:
            raise exceptions.InvalidID() from e


ObjectManagerDependency = DependencyCallable[BaseObjectManager[Object, ID]]
