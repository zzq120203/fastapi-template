# !/usr/bin/env Python3
# -*- coding: utf-8 -*-
# @Author   : zhangzhanqi
# @FILE     : __init__.py.py
# @Time     : 2023/8/2 11:51
from fastapi_plugin.db.base import BaseObjectDatabase, ObjectDatabaseDependency
from fastapi_plugin.db.manager import UUIDIDMixin, IntegerIDMixin, BaseObjectManager
from fastapi_plugin.db.router import BaseObjectRouter
from fastapi_plugin.db.sqlalchemy import (
    SQLAlchemyBaseObjectTable,
    SQLAlchemyBaseObjectTableUUID,
    SQLAlchemyObjectDatabase,
)

__all__ = [
    "BaseObjectDatabase", "ObjectDatabaseDependency",
    "UUIDIDMixin", "IntegerIDMixin", "BaseObjectManager",
    "BaseObjectRouter",
    "SQLAlchemyBaseObjectTable",
    "SQLAlchemyBaseObjectTableUUID",
    "SQLAlchemyObjectDatabase"
]
