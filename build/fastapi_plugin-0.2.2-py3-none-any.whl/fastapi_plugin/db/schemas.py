# !/usr/bin/env Python3
# -*- coding: utf-8 -*-
# @Author   : zhangzhanqi
# @FILE     : schemas.py
# @Time     : 2023/8/2 12:55
from datetime import datetime
from typing import Generic, Optional, TypeVar

from pydantic import BaseModel

from fastapi_plugin.db.models import ID

SCHEMA = TypeVar("SCHEMA", bound=BaseModel)


def convert_datetime_to_chinese(dt: datetime) -> str:
    return dt.strftime('%Y-%m-%d %H:%M:%S')


class CreateUpdateDictModel(BaseModel):

    def create_update_dict(self):
        return self.model_dump(
            exclude_unset=True,
            exclude={
                "id",
                "create_time",
                "update_time",
            },
            by_alias=True
        )


class BaseObjectRead(
    CreateUpdateDictModel,
    Generic[ID],
    from_attributes=True,
    json_encoders={
        datetime: convert_datetime_to_chinese
    }
):
    """Base Object model."""

    id: ID
    name: str
    create_time: datetime = datetime.now()
    update_time: datetime = datetime.now()


class BaseObjectCreate(CreateUpdateDictModel):
    name: str


class BaseObjectUpdate(CreateUpdateDictModel):
    name: Optional[str] = None


OR = TypeVar("OR", bound=BaseObjectRead)
OC = TypeVar("OC", bound=BaseObjectCreate)
OU = TypeVar("OU", bound=BaseObjectUpdate)
