from typing import Any, Dict, Generic, Optional, List, Tuple

from fastapi_plugin.common.typing import DependencyCallable
from fastapi_plugin.db.models import ID, Object


class BaseObjectDatabase(Generic[Object, ID]):
    """Base adapter for retrieving, creating and updating object from a database."""

    async def get(self, id: ID) -> Optional[Object]:
        """Get a single object by id."""
        raise NotImplementedError()

    async def get_by_name(self, name: str) -> Optional[Object]:
        """Get a single object by name."""
        raise NotImplementedError()

    async def get_all(
            self,
            query=None,
            order_by: List[str] = None,
            offset: Optional[int] = 1,
            limit: Optional[int] = None,
    ) -> Tuple[List[Object], int]:
        raise NotImplementedError()

    async def create(self, create_dict: Dict[str, Any]) -> Object:
        """Create a object."""
        raise NotImplementedError()

    async def update(self, obj: Object, update_dict: Dict[str, Any]) -> Object:
        """Update a object."""
        raise NotImplementedError()

    async def delete(self, obj: Object) -> None:
        """Delete a object."""
        raise NotImplementedError()


ObjectDatabaseDependency = DependencyCallable[BaseObjectDatabase[Object, ID]]
