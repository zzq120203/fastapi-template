from pydantic.version import VERSION as PYDANTIC_VERSION

assert PYDANTIC_VERSION.startswith('2.'), "pydantic version >= 2.0.0"
