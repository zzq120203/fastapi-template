from .applications import FastAPI
__all__ = [
    "FastAPI",
]
