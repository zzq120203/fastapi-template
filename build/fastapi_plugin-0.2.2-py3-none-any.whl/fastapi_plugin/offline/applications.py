import datetime
from pathlib import Path as _P
from typing import (
    Any,
    Callable,
    Coroutine,
    Dict,
    List,
    Optional,
    Sequence,
    Type,
    TypeVar,
    Union,
)

from fastapi import routing, FastAPI as _FastAPI, HTTPException
from fastapi.applications import AppType
from fastapi.datastructures import Default
from fastapi.exceptions import RequestValidationError
from fastapi.middleware import Middleware
from fastapi.openapi.docs import (
    get_redoc_html,
    get_swagger_ui_html,
    get_swagger_ui_oauth2_redirect_html,
)
from fastapi.params import Depends
from fastapi.requests import Request
from fastapi.responses import JSONResponse, Response, HTMLResponse
from fastapi.routing import BaseRoute
from fastapi.staticfiles import StaticFiles
from fastapi.utils import generate_unique_id
from starlette.types import Lifespan

from fastapi_plugin.common.exception_handlers import (
    http_exception_handler, request_validation_exception_handler, fastapi_plugin_exception_handler
)
from fastapi_plugin.common.exceptions import FastAPIPluginException


class FastAPI(_FastAPI):
    def __init__(
            self: AppType,
            *,
            debug: bool = False,
            routes: Optional[List[BaseRoute]] = None,
            title: str = "FastAPI",
            summary: Optional[str] = None,
            description: str = "",
            version: str = "0.1.0",
            openapi_url: Optional[str] = "/openapi.json",
            openapi_tags: Optional[List[Dict[str, Any]]] = None,
            servers: Optional[List[Dict[str, Union[str, Any]]]] = None,
            dependencies: Optional[Sequence[Depends]] = None,
            default_response_class: Type[Response] = Default(JSONResponse),
            redirect_slashes: bool = True,
            docs_url: Optional[str] = "/docs",
            redoc_url: Optional[str] = "/redoc",
            swagger_ui_oauth2_redirect_url: Optional[str] = "/docs/oauth2-redirect",
            swagger_ui_init_oauth: Optional[Dict[str, Any]] = None,
            middleware: Optional[Sequence[Middleware]] = None,
            exception_handlers: Optional[
                Dict[Union[int, Type[Exception]], Callable[[Request, Any], Coroutine[Any, Any, Response]]]] = None,
            on_startup: Optional[Sequence[Callable[[], Any]]] = None,
            on_shutdown: Optional[Sequence[Callable[[], Any]]] = None,
            lifespan: Optional[Lifespan[AppType]] = None,
            terms_of_service: Optional[str] = None,
            contact: Optional[Dict[str, Union[str, Any]]] = None,
            license_info: Optional[Dict[str, Union[str, Any]]] = None,
            openapi_prefix: str = "",
            root_path: str = "",
            root_path_in_servers: bool = True,
            responses: Optional[Dict[Union[int, str], Dict[str, Any]]] = None,
            callbacks: Optional[List[BaseRoute]] = None,
            webhooks: Optional[routing.APIRouter] = None,
            deprecated: Optional[bool] = None,
            include_in_schema: bool = True,
            swagger_ui_parameters: Optional[Dict[str, Any]] = None,
            generate_unique_id_function: Callable[[routing.APIRoute], str] = Default(generate_unique_id),
            heartbeat: bool = True,
            **extra: Any
    ) -> None:
        super().__init__(debug=debug, routes=routes, title=title, summary=summary, description=description,
                         version=version, openapi_url=openapi_url, openapi_tags=openapi_tags, servers=servers,
                         dependencies=dependencies, default_response_class=default_response_class,
                         redirect_slashes=redirect_slashes, docs_url=docs_url, redoc_url=redoc_url,
                         swagger_ui_oauth2_redirect_url=swagger_ui_oauth2_redirect_url,
                         swagger_ui_init_oauth=swagger_ui_init_oauth, middleware=middleware,
                         exception_handlers=exception_handlers, on_startup=on_startup, on_shutdown=on_shutdown,
                         lifespan=lifespan, terms_of_service=terms_of_service, contact=contact,
                         license_info=license_info, openapi_prefix=openapi_prefix, root_path=root_path,
                         root_path_in_servers=root_path_in_servers, responses=responses, callbacks=callbacks,
                         webhooks=webhooks, deprecated=deprecated, include_in_schema=include_in_schema,
                         swagger_ui_parameters=swagger_ui_parameters,
                         generate_unique_id_function=generate_unique_id_function, **extra)

        offline_dir = _P(__file__).parent.absolute() / "static"
        self.mount("/offline", StaticFiles(directory=offline_dir), name="offline")

        not heartbeat or self._heartbeat()

        self._add_default_exception_handler()

    def _heartbeat(self):
        """
        添加默认心跳监控接口
        """
        start_time = str(datetime.datetime.now())

        @self.get("/heartbeat", tags=['heartbeat'])
        async def heartbeat():
            return {"server": self.title, "run_time": start_time}

    def _add_default_exception_handler(
            self,
    ) -> None:
        """
        添加默认异常处理
        """
        self.add_exception_handler(HTTPException, http_exception_handler)
        self.add_exception_handler(404, http_exception_handler)
        self.add_exception_handler(RequestValidationError, request_validation_exception_handler)
        self.add_exception_handler(FastAPIPluginException, fastapi_plugin_exception_handler)

    def setup(self) -> None:
        if self.openapi_url:
            urls = (server_data.get("url") for server_data in self.servers)
            server_urls = {url for url in urls if url}

            async def openapi(req: Request) -> JSONResponse:
                root_path = req.scope.get("root_path", "").rstrip("/")
                if root_path not in server_urls:
                    if root_path and self.root_path_in_servers:
                        self.servers.insert(0, {"url": root_path})
                        server_urls.add(root_path)
                return JSONResponse(self.openapi())

            self.add_route(self.openapi_url, openapi, include_in_schema=False)
        if self.openapi_url and self.docs_url:

            async def swagger_ui_html(req: Request) -> HTMLResponse:
                root_path = req.scope.get("root_path", "").rstrip("/")
                openapi_url = root_path + self.openapi_url
                oauth2_redirect_url = self.swagger_ui_oauth2_redirect_url
                if oauth2_redirect_url:
                    oauth2_redirect_url = root_path + oauth2_redirect_url
                return get_swagger_ui_html(
                    openapi_url=openapi_url,
                    title=self.title + " - Swagger UI",
                    oauth2_redirect_url=oauth2_redirect_url,
                    init_oauth=self.swagger_ui_init_oauth,
                    swagger_ui_parameters=self.swagger_ui_parameters,
                    swagger_js_url="/offline/swagger-ui-bundle.js",
                    swagger_css_url="/offline/swagger-ui.css",
                    swagger_favicon_url="/offline/favicon.png",
                )

            self.add_route(self.docs_url, swagger_ui_html, include_in_schema=False)

            if self.swagger_ui_oauth2_redirect_url:
                async def swagger_ui_redirect(req: Request) -> HTMLResponse:
                    return get_swagger_ui_oauth2_redirect_html()

                self.add_route(
                    self.swagger_ui_oauth2_redirect_url,
                    swagger_ui_redirect,
                    include_in_schema=False,
                )
        if self.openapi_url and self.redoc_url:
            async def redoc_html(req: Request) -> HTMLResponse:
                root_path = req.scope.get("root_path", "").rstrip("/")
                openapi_url = root_path + self.openapi_url
                return get_redoc_html(
                    openapi_url=openapi_url, title=self.title + " - ReDoc",
                    redoc_js_url="/offline/redoc.standalone.js",
                    redoc_favicon_url="/offline/favicon.png",
                )

            self.add_route(self.redoc_url, redoc_html, include_in_schema=False)
